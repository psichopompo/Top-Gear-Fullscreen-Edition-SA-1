TopGear - Fullscreen Edition — v1.0 — SA-1
by Psicopompo

Top Gear for Super Nintendo, featuring full-screen single-player racing,
SA-1 support, and performance and presentation improvements.

CHANGES
- Single-player races have been expanded to fill the screen, removing the lower view of the second car in this mode.
- SA-1 support and additional performance optimizations have been incorporated.
- The HUD has been adapted to the expanded view.
- The transition to RESULTS in single-player mode has been corrected.
- Position updates during pit stops have been corrected.
- Sky flashes, lap-message display issues and bridge graphics have been corrected, including objects appearing over bridge walls.

HOW TO APPLY THE PATCH
1. Extract the ZIP archive.
2. Open Rom Patcher JS: https://www.marcrobledo.com/RomPatcher.js/
3. Select an unmodified Top Gear (USA) ROM without a copier header: 524,288 bytes, CRC32 D34C49B7.
4. Select either the included .bps patch or the .ips patch. Both produce the same ROM: apply ONLY ONE, directly to the original USA ROM.
5. Apply the patch and save the result as:
   TopGear - Fullscreen Edition (v1.0) (SA-1) (by Psicopompo).sfc
6. Open the patched ROM in an SA-1-compatible environment and start from a fresh boot.

The patches in this package are complete. No previous version of the hack
is required. Do not apply both patches or use an already modified ROM.
The ZIP contains both patches and the Spanish and English readme files;
no ROM is included.

REQUIRED ORIGINAL ROM
Game: Top Gear (USA)
Size: 524,288 bytes (512 KiB), without a 512-byte copier header.
CRC32: D34C49B7
SHA-256: ca9889f17f184b3d99a2eaaa82af73e366f03ed00313fdd369e5e023b208e788

PATCHED ROM
Size: 1,048,576 bytes (1 MiB).
SHA-256: a7d7cccfb9ecda63e593e27c1fa8d2e5c1ac680c60369b6e0457734f5e15801f

RUNNING THE GAME
SA-1 support is required. Tested with Mesen 2.2.1.

CREDITS
Hack: Psicopompo.
Top Gear and its original assets belong to their respective owners.
